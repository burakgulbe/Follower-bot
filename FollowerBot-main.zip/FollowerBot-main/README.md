# Usage
install requirements in a new virtual environment using pip install -r requirements.txt.

# FollowerBot
Follower bot for Instagram:

Before running the program, please enter your Gmail credentials. Because the server side added a control to send followers. If the server doesn't send followers to you anymore, please add a new Gmail account.
After you run the program, enter your instagram username and get free Instagram followers. It sends 10 followers at a time! No need to enter your Instagram password to the system. PS: You have to have a public profile to get free followers. 

# LikeBot
Liker bot for Instagram:

Before running the program, please enter your Gmail credentials. Because the server side added a control to send likes. If the server doesn't send likes to you anymore, please add a new Gmail account.
After you run the program, enter your instagram post URL and get free Instagram likes. It sends 100 likes at a time! No need to enter your Instagram password to the system. PS: ou have to have a public profile to get free likes.

# Open a Fake Gmail Account

To open a fake Gmail account, please follow these steps.

1) Go to create Gmail account web page.
2) Find a unique Gmail address.
3) To add mobile phone number, please use https://getfreesmsnumber.com/ web page.
4) Confirm and here we go!

# Get Credit

I wrote a bot program for websites that the more credits you earn, the more followers and likes you can gain. The bot helps you earn credits by going to the relevant website and watching videos in the background. In order to convert these credits into followers or likes, you need to go to the website manually from your browser and make the definitions.

# Remarks

When you get expiration error on get_instagram_followers.py or get_instagram_likes.py programs, please change your Instagram username and start the bot again.

Although you change your username and still get expiration error, please try VPN and start the bot again. For example: Hotspot Shield Free VPN program.

# Donations
If you feel like showing your love and/or appreciation for this project, then how about shouting me a coffee or beer :)

<a href="https://www.buymeacoffee.com/asimzorlu" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>
